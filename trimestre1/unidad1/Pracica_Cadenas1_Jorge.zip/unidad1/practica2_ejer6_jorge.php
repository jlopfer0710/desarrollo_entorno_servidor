<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Ejercicio 6</title>
</head>
<body>
	<?php  
		$numero=696;
		printf ("El numero en decimal es: %d",$numero);
		printf ("<br>El numero en binario es: %b",$numero);
		printf ("<br>El numero en octal es: %o",$numero);
	?>
</body>
</html>